'use client';

import { Brain } from 'lucide-react';
import { Button } from '@/components/ui';
import { motion } from 'framer-motion';

interface ContinuityScreenProps {
    onContinue: () => void; // This will trigger the checkout/upgrade flow
}

export function ContinuityScreen({ onContinue }: ContinuityScreenProps) {
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/95 backdrop-blur-sm p-4">
            <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="max-w-md w-full text-center"
            >
                <div className="mb-8 flex justify-center">
                    <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-indigo-500/20 to-purple-500/20 flex items-center justify-center ring-1 ring-white/10 shadow-[0_0_30px_-5px_rgba(99,102,241,0.3)]">
                        <Brain className="h-8 w-8 text-indigo-400" />
                    </div>
                </div>

                <h2 className="text-3xl font-light text-white mb-2 tracking-wide">Süreklilik</h2>

                <p className="text-lg text-slate-300 mb-8 italic font-light leading-relaxed">
                    &quot;Ben seninle konuşmak için değil,<br />
                    seni hatırlamak için buradayım.&quot;
                </p>

                <div className="space-y-6">
                    <p className="text-sm text-slate-500 max-w-xs mx-auto">
                        Free kullanım kısa temas içindir.<br />
                        Derinlik, süreklilik ister.
                    </p>

                    <Button
                        onClick={onContinue}
                        className="w-full max-w-xs h-12 text-base bg-white text-slate-900 hover:bg-slate-100 transition-all duration-300 font-medium"
                    >
                        Devam Et
                    </Button>
                </div>
            </motion.div>
        </div>
    );
}
